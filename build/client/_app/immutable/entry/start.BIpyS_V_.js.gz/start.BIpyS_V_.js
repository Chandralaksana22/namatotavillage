import{a as t}from"../chunks/entry.DACBHv48.js";export{t as start};
