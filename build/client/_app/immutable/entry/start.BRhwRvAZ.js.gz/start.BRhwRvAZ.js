import{a as t}from"../chunks/entry.Cjvnyv9p.js";export{t as start};
