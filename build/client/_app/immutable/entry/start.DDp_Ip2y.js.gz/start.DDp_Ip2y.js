import{a as t}from"../chunks/entry.BA-Zbcd1.js";export{t as start};
