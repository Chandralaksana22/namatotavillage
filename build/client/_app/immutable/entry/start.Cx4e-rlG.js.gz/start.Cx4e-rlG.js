import{a as t}from"../chunks/entry.Bvnb9_Po.js";export{t as start};
