import{a as t}from"../chunks/entry.DWItEG_V.js";export{t as start};
