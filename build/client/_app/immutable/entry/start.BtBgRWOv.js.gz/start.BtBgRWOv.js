import{a as t}from"../chunks/entry.Cc2XzZK0.js";export{t as start};
