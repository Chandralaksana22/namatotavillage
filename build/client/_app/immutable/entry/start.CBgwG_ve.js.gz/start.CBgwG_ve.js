import{a as t}from"../chunks/entry.Br4VW1Cs.js";export{t as start};
