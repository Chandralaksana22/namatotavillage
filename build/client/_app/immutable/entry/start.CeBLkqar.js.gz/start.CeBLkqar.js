import{a as t}from"../chunks/entry.DpqwLh77.js";export{t as start};
