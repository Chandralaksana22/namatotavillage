import{a as t}from"../chunks/entry.BeQcgWo2.js";export{t as start};
